<?php

namespace App\Http\Controllers;

use App\Models\Alumno;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AlumnoController extends Controller
{
    // LEER TODOS - GET /api/alumnos - 200
    public function index()
    {
        return response()->json(Alumno::all(), 200);
    }

    // CREAR - POST /api/alumnos - 201 o 400
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nombre' => 'required|string|max:255',
            'matricula' => 'required|string|unique:alumnos,matricula',
            'correo' => 'required|email|unique:alumnos,correo',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'mensaje' => 'Datos invalidos',
                'errores' => $validator->errors()
            ], 400);
        }

        $alumno = Alumno::create($request->all());

        return response()->json([
            'mensaje' => 'Alumno creado correctamente',
            'alumno' => $alumno
        ], 201);
    }

    // LEER UNO - GET /api/alumnos/{id} - 200 o 404
    public function show($id)
    {
        $alumno = Alumno::find($id);

        if (!$alumno) {
            return response()->json(['mensaje' => 'Alumno no encontrado'], 404);
        }

        return response()->json($alumno, 200);
    }

    // ACTUALIZAR - PUT y PATCH /api/alumnos/{id} - 200, 400 o 404
    public function update(Request $request, $id)
    {
        $alumno = Alumno::find($id);

        if (!$alumno) {
            return response()->json(['mensaje' => 'Alumno no encontrado'], 404);
        }

        $validator = Validator::make($request->all(), [
            'nombre' => 'sometimes|required|string|max:255',
            'matricula' => 'sometimes|required|string|unique:alumnos,matricula,' . $id,
            'correo' => 'sometimes|required|email|unique:alumnos,correo,' . $id,
        ]);

        if ($validator->fails()) {
            return response()->json([
                'mensaje' => 'Datos invalidos',
                'errores' => $validator->errors()
            ], 400);
        }

        $alumno->update($request->all());

        return response()->json([
            'mensaje' => 'Alumno actualizado correctamente',
            'alumno' => $alumno
        ], 200);
    }

    // ELIMINAR - DELETE /api/alumnos/{id} - 200 o 404
    public function destroy($id)
    {
        $alumno = Alumno::find($id);

        if (!$alumno) {
            return response()->json(['mensaje' => 'Alumno no encontrado'], 404);
        }

        $alumno->delete();

        return response()->json(['mensaje' => 'Alumno eliminado correctamente'], 200);
    }
}